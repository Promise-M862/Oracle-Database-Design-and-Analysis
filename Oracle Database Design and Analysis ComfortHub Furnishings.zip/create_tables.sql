Promise Makgopa 4367105

create_tables.sql 


CREATE TABLE categories
    (category_code            NUMBER(3) PRIMARY KEY,
     category_name            VARCHAR2(40) NOT NULL,
     category_description     VARCHAR(200));
    
    
CREATE TABLE suppliers
    (supplier_code            NUMBER(3) PRIMARY KEY,
     supplier_name            VARCHAR2(40) NOT NULL,
     supplier_city            VARCHAR2(30) NOT NULL,
     supplier_email           VARCHAR2(50) NOT NULL,
     CONSTRAINT supplier_email_uk UNIQUE(supplier_email));
     
CREATE TABLE products
    (product_code             NUMBER(3) PRIMARY KEY,
     product_name             VARCHAR2(40) NOT NULL,
     product_price            NUMBER(6) NOT NULL,
     product_description      VARCHAR2(200),
     category_code            NUMBER(3) NOT NULL,
     supplier_code            NUMBER(3) NOT NULL,
     CONSTRAINT category_code_fk FOREIGN KEY (category_code) 
       REFERENCES categories(category_code),
     CONSTRAINT supplier_code_fk FOREIGN KEY (supplier_code)
       REFERENCES suppliers(supplier_code));