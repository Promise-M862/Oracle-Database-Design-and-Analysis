Promise Makgopa 4367105

insert_data.sql 


INSERT INTO categories(category_code, category_name, category_description)
VALUES(100, 'Sofas', 'Select from a range of sofas');
INSERT INTO categories(category_code, category_name, category_description)
VALUES(101, 'Beds', 'Select from a range of beds');
INSERT INTO categories(category_code, category_name, category_description)
VALUES(102, 'Dining Tables', 'Select from a range of kitchen tables');
INSERT INTO categories(category_code, category_name, category_description)
VALUES(103, 'Office Furniture', 'Professional and ergonomic office furniture solutions');

INSERT INTO suppliers(supplier_code, supplier_name, supplier_city, supplier_email)
VALUES(125, 'Eames Aesthetic', 'Oxford', 'info244@eames.com');
INSERT INTO suppliers(supplier_code, supplier_name, supplier_city, supplier_email)
VALUES(126, 'Furno', 'London', 'supply244@furno.com');
INSERT INTO suppliers(supplier_code, supplier_name, supplier_city, supplier_email)
VALUES(127, 'Nordic Comfort', 'Manchester', 'contact@nordiccomfort.co.uk');

INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(1, 'Corner Sofa', 'A modern day corner sofa suitable for a small family.', 1150, 100, 126);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(2, '3 Seat Sofa', 'Ideal for those who love crashing in front of the television.', 700, 100, 126);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(3, 'Queen Sized Bed', 'A queen sized luxury comfort bed.', 1300, 101, 126);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(4, '5 Piece Kitchen Table', 'A 5 piece kitchen table set with 1 table and 4 chairs.', 400, 102, 125);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(5, '9 Piece Kitchen Table', 'A 9 piece kitchen table set with 1 table and 8 chairs.', 750, 102, 125);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(6, 'Executive Desk', 'Large wooden executive desk with built-in cable management.', 1200, 103, 127);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(7, 'Ergonomic Office Chair', 'Fully adjustable ergonomic chair with lumbar support.', 450, 103, 127);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(8, 'King Sized Bed', 'Luxurious king sized bed with premium mattress.', 1800, 101, 126);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(9, 'Reclining Sofa', 'Comfortable three-seater sofa with reclining features.', 1250, 100, 126);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(10, '7 Piece Kitchen Table', 'Expandable dining set with 6 chairs and leaf extension.', 900, 102, 125);
INSERT INTO products(product_code, product_name, product_description, product_price, category_code, supplier_code)
VALUES(11, 'Modern Sectional Sofa', 'L-shaped sectional sofa with contemporary design.', 1600, 100, 126);
