Promise Makgopa 4367105

strategic_query.sql 


WITH category_revenue as (SELECT c.category_name, s.supplier_name, COUNT(p.product_code) as total_products, AVG(p.product_price) as avg_product_price, SUM(p.product_price) as total_revenue
FROM products p
FULL OUTER JOIN categories c ON p.category_code = c.category_code
FULL OUTER JOIN suppliers s ON p.supplier_code = s.supplier_code
GROUP BY c.category_name, s.supplier_name)
SELECT category_name, supplier_name, total_products, avg_product_price, total_revenue, RANK() OVER (ORDER BY total_revenue DESC) as revenue_rank
FROM category_revenue
ORDER BY avg_product_price;